<?php
namespace Index\Controller;
use Index\Helper\Flag;



defined('ACCESS_FILE') or exit('No direct script access allowed');
// ini_set('display_errors', '0');
// error_reporting(E_ALL ^ E_NOTICE);

class Trans extends Base
{
    public function __construct()
    {
        parent::__construct();
        // $this->com($user);
    }


}
